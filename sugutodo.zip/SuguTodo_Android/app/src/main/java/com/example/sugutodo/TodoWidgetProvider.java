package com.example.sugutodo;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;
import java.time.LocalDate;
import java.util.List;

/** Standard Android home-screen widget; no external libraries or account needed. */
public final class TodoWidgetProvider extends AppWidgetProvider {
    private static final int[] ROW_IDS = {
        R.id.widget_row_1, R.id.widget_row_2,
        R.id.widget_row_3, R.id.widget_row_4
    };
    private static final int FLAGS = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateOne(context, manager, id);
    }

    @Override public void onEnabled(Context context) {
        updateAll(context);
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, TodoWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int widgetId) {
        TodoDb db = new TodoDb(context);
        List<Task> visible;
        int count;
        try {
            visible = db.getActive(ROW_IDS.length);
            count = db.countActive();
        } finally {
            db.close();
        }

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_todo);
        views.setTextViewText(R.id.widget_counter, count + "件");
        views.setViewVisibility(R.id.widget_empty, count == 0 ? View.VISIBLE : View.GONE);

        Intent open = new Intent(context, MainActivity.class);
        open.setAction(Intent.ACTION_MAIN);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        views.setOnClickPendingIntent(R.id.widget_open, PendingIntent.getActivity(context, 9001, open, FLAGS));

        Intent add = new Intent(context, MainActivity.class);
        add.setAction(MainActivity.ACTION_ADD);
        add.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        views.setOnClickPendingIntent(R.id.widget_add, PendingIntent.getActivity(context, 9002, add, FLAGS));

        for (int i = 0; i < ROW_IDS.length; i++) {
            int rowId = ROW_IDS[i];
            if (i >= visible.size()) {
                views.setViewVisibility(rowId, View.GONE);
                continue;
            }
            Task task = visible.get(i);
            views.setViewVisibility(rowId, View.VISIBLE);
            StringBuilder line = new StringBuilder("☐  ").append(task.title);
            boolean overdue = false;
            if (!task.dueDate.isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(task.dueDate);
                    overdue = date.isBefore(LocalDate.now());
                    line.append("  · ").append(date.getMonthValue()).append("/").append(date.getDayOfMonth());
                } catch (RuntimeException ignored) { /* Keep task visible if an old date is malformed. */ }
            }
            views.setTextViewText(rowId, line.toString());
            views.setTextColor(rowId, overdue ? Color.rgb(202, 61, 76) : Color.rgb(38, 49, 75));
            Intent toggle = new Intent(context, TaskActionReceiver.class);
            toggle.setAction(TaskActionReceiver.ACTION_TOGGLE);
            toggle.setData(Uri.parse("sugutodo://toggle/" + task.id));
            toggle.putExtra(TaskActionReceiver.EXTRA_ID, task.id);
            PendingIntent pending = PendingIntent.getBroadcast(context, 0, toggle, FLAGS);
            views.setOnClickPendingIntent(rowId, pending);
        }
        manager.updateAppWidget(widgetId, views);
    }
}
