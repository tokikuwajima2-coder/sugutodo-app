package com.example.sugutodo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Non-exported receiver: tasks can be toggled by this app's widget PendingIntents. */
public final class TaskActionReceiver extends BroadcastReceiver {
    public static final String ACTION_TOGGLE = "com.example.sugutodo.TOGGLE";
    public static final String EXTRA_ID = "task_id";

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION_TOGGLE.equals(intent.getAction())) return;
        long id = intent.getLongExtra(EXTRA_ID, -1L);
        if (id <= 0) return;
        TodoDb db = new TodoDb(context);
        try {
            db.toggle(id);
        } finally {
            db.close();
        }
        TodoWidgetProvider.updateAll(context);
    }
}
