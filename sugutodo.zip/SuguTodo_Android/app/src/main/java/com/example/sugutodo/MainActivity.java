package com.example.sugutodo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Small, entirely native Android ToDo app.
 * Works offline, stores tasks locally in SQLite, and refreshes its home-screen widget.
 */
public final class MainActivity extends Activity {
    public static final String ACTION_ADD = "com.example.sugutodo.OPEN_ADD";

    private static final int BG = Color.rgb(247, 248, 252);
    private static final int WHITE = Color.WHITE;
    private static final int TEXT = Color.rgb(32, 41, 65);
    private static final int MUTED = Color.rgb(113, 123, 145);
    private static final int PURPLE = Color.rgb(89, 106, 232);
    private static final int BORDER = Color.rgb(232, 235, 245);
    private static final int RED = Color.rgb(204, 69, 86);
    private static final DateTimeFormatter JP_DATE =
            DateTimeFormatter.ofPattern("M月d日（E）", Locale.JAPAN);

    private TodoDb db;
    private LinearLayout content;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new TodoDb(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        render();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        render();
        handleIntent(intent);
    }

    @Override protected void onResume() {
        super.onResume();
        if (db != null && content != null) render();
    }

    @Override protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }

    private void handleIntent(Intent intent) {
        if (intent == null || !ACTION_ADD.equals(intent.getAction())) return;
        intent.setAction(Intent.ACTION_MAIN); // Avoid duplicate add dialogs on rotation/reopen.
        if (content != null) content.post(() -> showTaskDialog(null));
    }

    private void render() {
        List<Task> all = db.getAll();
        List<Task> active = new ArrayList<>();
        List<Task> completed = new ArrayList<>();
        for (Task task : all) {
            if (task.done) completed.add(task);
            else active.add(task);
        }

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(BG);
        screen.setFitsSystemWindows(true);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        screen.addView(scroll, new LinearLayout.LayoutParams(-1, -1));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(19), dp(24), dp(19), dp(42));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));

        buildHeader();
        buildSummary(active.size(), completed.size());
        buildSection("まだやること", active.size(), false);
        if (active.isEmpty()) buildEmptyState();
        else for (Task t : active) buildTaskCard(t);

        if (!completed.isEmpty()) {
            buildSection("完了したこと", completed.size(), true);
            for (Task t : completed) buildTaskCard(t);
        }
        buildWidgetTip();
        setContentView(screen);
    }

    private void buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams hParams = lp(-1, -2);
        hParams.bottomMargin = dp(24);
        content.addView(header, hParams);

        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView eyebrow = text("MY TASKS", 11, PURPLE, true);
        eyebrow.setLetterSpacing(.16f);
        heading.addView(eyebrow);
        TextView title = text("すぐToDo", 29, TEXT, true);
        LinearLayout.LayoutParams tp = lp(-1, -2);
        tp.topMargin = dp(3);
        heading.addView(title, tp);

        TextView add = text("＋ 追加", 15, WHITE, true);
        add.setGravity(Gravity.CENTER);
        add.setPadding(dp(18), dp(13), dp(18), dp(13));
        add.setBackground(round(PURPLE, 16, 0));
        add.setElevation(dp(3));
        add.setContentDescription("新しいタスクを追加");
        add.setOnClickListener(v -> showTaskDialog(null));
        header.addView(add);
    }

    private void buildSummary(int active, int done) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(21), dp(21), dp(21), dp(20));
        card.setBackground(round(Color.rgb(32, 42, 73), 21, 0));
        LinearLayout.LayoutParams cp = lp(-1, -2);
        cp.bottomMargin = dp(26);
        content.addView(card, cp);

        TextView small = text("今日も、ひとつずつ。", 14, Color.rgb(207, 216, 247), false);
        card.addView(small);
        TextView count = text("残り " + active + " 件", 32, WHITE, true);
        LinearLayout.LayoutParams ct = lp(-1, -2);
        ct.topMargin = dp(8);
        card.addView(count, ct);
        int total = active + done;
        String progress = total == 0 ? "最初のタスクを追加してみよう" :
                "完了 " + done + " / " + total + " 件  ·  " + (done * 100 / total) + "%";
        TextView detail = text(progress, 12, Color.rgb(190, 200, 231), false);
        LinearLayout.LayoutParams dp = lp(-1, -2);
        dp.topMargin = dp(7);
        card.addView(detail, dp);
    }

    private void buildSection(String name, int count, boolean completed) {
        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams sp = lp(-1, -2);
        sp.topMargin = dp(completed ? 25 : 1);
        sp.bottomMargin = dp(12);
        content.addView(section, sp);
        TextView label = text(name, 19, TEXT, true);
        section.addView(label);
        TextView badge = text(" " + count + " ", 12, completed ? MUTED : PURPLE, true);
        badge.setPadding(dp(9), dp(3), dp(9), dp(3));
        badge.setBackground(round(Color.rgb(236, 238, 249), 18, 0));
        LinearLayout.LayoutParams bp = lp(-2, -2);
        bp.leftMargin = dp(9);
        section.addView(badge, bp);
    }

    private void buildEmptyState() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(27), dp(20), dp(27));
        box.setGravity(Gravity.CENTER);
        box.setBackground(round(WHITE, 17, BORDER));
        content.addView(box, lp(-1, -2));
        TextView headline = text("今日は何をしよう？", 17, TEXT, true);
        box.addView(headline);
        TextView subtitle = text("右上の「＋ 追加」でタスクを作成できます。", 13, MUTED, false);
        LinearLayout.LayoutParams subp = lp(-2, -2);
        subp.topMargin = dp(8);
        box.addView(subtitle, subp);
    }

    private void buildTaskCard(Task task) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(12), dp(8), dp(12));
        row.setBackground(round(WHITE, 16, BORDER));
        row.setElevation(dp(1));
        LinearLayout.LayoutParams rowp = lp(-1, -2);
        rowp.bottomMargin = dp(10);
        content.addView(row, rowp);

        CheckBox check = new CheckBox(this);
        check.setChecked(task.done);
        check.setButtonTintList(ColorStateList.valueOf(PURPLE));
        check.setContentDescription(task.done ? "タスクを未完了に戻す" : "タスクを完了する");
        row.addView(check, lp(dp(48), dp(48)));
        check.setOnCheckedChangeListener((button, value) -> {
            db.setDone(task.id, value);
            TodoWidgetProvider.updateAll(this);
            render();
        });

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams labelsP = new LinearLayout.LayoutParams(0, -2, 1f);
        labelsP.leftMargin = dp(1);
        row.addView(labels, labelsP);

        TextView title = text(task.title, 15, task.done ? MUTED : TEXT, true);
        title.setMaxLines(3);
        if (task.done) title.setPaintFlags(title.getPaintFlags() | 16); // STRIKE_THRU_TEXT_FLAG
        labels.addView(title);

        StringBuilder meta = new StringBuilder();
        boolean overdue = false;
        if (!task.dueDate.isEmpty()) {
            try {
                LocalDate due = LocalDate.parse(task.dueDate);
                LocalDate today = LocalDate.now();
                overdue = due.isBefore(today) && !task.done;
                if (overdue) meta.append("期限切れ · ");
                else if (due.isEqual(today)) meta.append("今日 · ");
                meta.append(due.format(JP_DATE));
            } catch (RuntimeException ignored) { /* A malformed date must not crash the list. */ }
        }
        if (task.priority == 2) {
            if (meta.length() > 0) meta.append("   ·   ");
            meta.append("優先度：高");
        } else if (task.priority == 0) {
            if (meta.length() > 0) meta.append("   ·   ");
            meta.append("優先度：低");
        }
        if (meta.length() > 0) {
            TextView detail = text(meta.toString(), 11, overdue ? RED : MUTED, false);
            LinearLayout.LayoutParams d = lp(-1, -2);
            d.topMargin = dp(5);
            labels.addView(detail, d);
        }
        labels.setOnClickListener(v -> showTaskDialog(task));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams actionsP = lp(dp(43), -2);
        actionsP.leftMargin = dp(5);
        row.addView(actions, actionsP);
        TextView edit = actionText("編集", PURPLE);
        edit.setContentDescription(task.title + "を編集");
        edit.setOnClickListener(v -> showTaskDialog(task));
        actions.addView(edit, lp(-1, dp(31)));
        TextView delete = actionText("削除", RED);
        delete.setContentDescription(task.title + "を削除");
        delete.setOnClickListener(v -> confirmDelete(task));
        actions.addView(delete, lp(-1, dp(31)));
    }

    private TextView actionText(String name, int color) {
        TextView tv = text(name, 12, color, true);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private void buildWidgetTip() {
        LinearLayout tip = new LinearLayout(this);
        tip.setOrientation(LinearLayout.VERTICAL);
        tip.setPadding(dp(16), dp(15), dp(16), dp(15));
        tip.setBackground(round(Color.rgb(235, 238, 253), 15, 0));
        LinearLayout.LayoutParams tp = lp(-1, -2);
        tp.topMargin = dp(22);
        content.addView(tip, tp);
        tip.addView(text("⌂  ホーム画面でもチェック！", 14, TEXT, true));
        TextView line = text("ホーム画面を長押し → ウィジェット →「すぐToDo」を追加。タスクをタップすると完了になります。", 12, MUTED, false);
        LinearLayout.LayoutParams lp = lp(-1, -2);
        lp.topMargin = dp(6);
        tip.addView(line, lp);
    }

    private void confirmDelete(Task task) {
        new AlertDialog.Builder(this)
            .setTitle("タスクを削除しますか？")
            .setMessage("「" + task.title + "」を削除します。この操作は取り消せません。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("削除", (dialog, which) -> {
                db.delete(task.id);
                TodoWidgetProvider.updateAll(this);
                render();
            })
            .show();
    }

    private void showTaskDialog(Task editing) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(5), dp(20), dp(3));

        form.addView(text("タスク名", 13, TEXT, true));
        EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setMaxLines(3);
        input.setTextSize(16);
        input.setHint("例：レポートを提出する");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
        if (editing != null) input.setText(editing.title);
        LinearLayout.LayoutParams ip = lp(-1, -2);
        ip.bottomMargin = dp(19);
        form.addView(input, ip);

        form.addView(text("期限", 13, TEXT, true));
        final String[] date = {editing == null ? "" : editing.dueDate};
        LinearLayout dateRow = new LinearLayout(this);
        dateRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams dateParams = lp(-1, -2);
        dateParams.topMargin = dp(9);
        dateParams.bottomMargin = dp(19);
        form.addView(dateRow, dateParams);

        TextView dateButton = text(dateLabel(date[0]), 14, PURPLE, true);
        dateButton.setGravity(Gravity.CENTER_VERTICAL);
        dateButton.setPadding(dp(13), dp(13), dp(12), dp(13));
        dateButton.setBackground(round(Color.rgb(235, 238, 253), 10, 0));
        dateRow.addView(dateButton, new LinearLayout.LayoutParams(0, -2, 1f));
        dateButton.setOnClickListener(v -> {
            LocalDate selected;
            try {
                selected = date[0].isEmpty() ? LocalDate.now() : LocalDate.parse(date[0]);
            } catch (RuntimeException ignored) {
                selected = LocalDate.now();
            }
            DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
                date[0] = LocalDate.of(year, month + 1, day).toString();
                dateButton.setText(dateLabel(date[0]));
            }, selected.getYear(), selected.getMonthValue() - 1, selected.getDayOfMonth());
            picker.show();
        });
        TextView clear = text("クリア", 12, MUTED, true);
        clear.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = lp(dp(65), dp(45));
        cp.leftMargin = dp(5);
        dateRow.addView(clear, cp);
        clear.setOnClickListener(v -> {
            date[0] = "";
            dateButton.setText(dateLabel(date[0]));
        });

        form.addView(text("優先度", 13, TEXT, true));
        Spinner priorities = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{"低い", "ふつう", "高い"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        priorities.setAdapter(adapter);
        priorities.setSelection(editing == null ? 1 : editing.priority);
        LinearLayout.LayoutParams pp = lp(-1, dp(50));
        pp.topMargin = dp(3);
        form.addView(priorities, pp);

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(editing == null ? "タスクを追加" : "タスクを編集")
            .setView(form)
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("保存", null)
            .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String title = input.getText().toString().trim();
            if (title.isEmpty()) {
                input.setError("タスク名を入力してください");
                input.requestFocus();
                return;
            }
            int priority = priorities.getSelectedItemPosition();
            if (editing == null) db.add(title, date[0], priority);
            else db.edit(editing.id, title, date[0], priority);
            TodoWidgetProvider.updateAll(this);
            dialog.dismiss();
            render();
        }));
        dialog.show();
    }

    private String dateLabel(String iso) {
        if (iso == null || iso.isEmpty()) return "📅  期限なし（タップで選択）";
        try { return "📅  " + LocalDate.parse(iso).format(JP_DATE); }
        catch (RuntimeException e) { return "📅  期限を選択"; }
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sizeSp);
        tv.setTextColor(color);
        tv.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return tv;
    }

    private GradientDrawable round(int bgColor, int radiusDp, int borderColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dp(radiusDp));
        if (borderColor != 0) bg.setStroke(dp(1), borderColor);
        return bg;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }
}
