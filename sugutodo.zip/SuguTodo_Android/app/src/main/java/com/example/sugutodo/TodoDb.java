package com.example.sugutodo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** Device-local persistence. No account, permission, or network required. */
public final class TodoDb extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "sugutodo.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE = "tasks";
    private static final String ORDER = "done ASC, " +
            "CASE WHEN due_date = '' THEN 1 ELSE 0 END ASC, " +
            "due_date ASC, priority DESC, created_at DESC";

    public TodoDb(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
            "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "title TEXT NOT NULL, " +
            "due_date TEXT NOT NULL DEFAULT '', " +
            "priority INTEGER NOT NULL DEFAULT 1, " +
            "done INTEGER NOT NULL DEFAULT 0, " +
            "created_at INTEGER NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Future migrations should go here; do not drop user data.
    }

    public long add(String title, String dueDate, int priority) {
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("due_date", dueDate);
        values.put("priority", priority);
        values.put("done", 0);
        values.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insertOrThrow(TABLE, null, values);
    }

    public void edit(long id, String title, String dueDate, int priority) {
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("due_date", dueDate);
        values.put("priority", priority);
        getWritableDatabase().update(TABLE, values, "_id=?", new String[]{String.valueOf(id)});
    }

    public void delete(long id) {
        getWritableDatabase().delete(TABLE, "_id=?", new String[]{String.valueOf(id)});
    }

    public void setDone(long id, boolean done) {
        ContentValues values = new ContentValues();
        values.put("done", done ? 1 : 0);
        getWritableDatabase().update(TABLE, values, "_id=?", new String[]{String.valueOf(id)});
    }

    public void toggle(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE " + TABLE + " SET done = CASE done WHEN 0 THEN 1 ELSE 0 END WHERE _id = ?",
                new Object[]{id});
    }

    public List<Task> getAll() {
        return query(null, null, null);
    }

    public List<Task> getActive(int limit) {
        return query("done=0", null, String.valueOf(limit));
    }

    private List<Task> query(String selection, String[] args, String limit) {
        List<Task> tasks = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(
                TABLE, null, selection, args, null, null, ORDER, limit)) {
            while (c.moveToNext()) tasks.add(Task.fromCursor(c));
        }
        return tasks;
    }

    public int countActive() {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM " + TABLE + " WHERE done=0", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }
}
