package com.example.sugutodo;

import android.database.Cursor;

public final class Task {
    public final long id;
    public final String title;
    public final String dueDate;
    public final int priority;
    public final boolean done;

    Task(long id, String title, String dueDate, int priority, boolean done) {
        this.id = id;
        this.title = title;
        this.dueDate = dueDate;
        this.priority = priority;
        this.done = done;
    }

    static Task fromCursor(Cursor c) {
        return new Task(
            c.getLong(c.getColumnIndexOrThrow("_id")),
            c.getString(c.getColumnIndexOrThrow("title")),
            c.getString(c.getColumnIndexOrThrow("due_date")),
            c.getInt(c.getColumnIndexOrThrow("priority")),
            c.getInt(c.getColumnIndexOrThrow("done")) != 0
        );
    }
}
