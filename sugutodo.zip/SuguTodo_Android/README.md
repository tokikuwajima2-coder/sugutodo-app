# すぐToDo（Android版）

スマホのホーム画面に置ける**ネイティブウィジェット付き**ToDoアプリです。
オフライン動作、広告なし、アカウント登録なし。タスクはスマホ内のSQLiteに保存されます。

## できること

- ToDoタスクの追加・編集・削除
- タスクの完了・未完了への戻し
- 期限の設定・解除、期限切れ表示
- 優先度（低い・ふつう・高い）
- 未完了・完了タスクの区分表示
- Androidのホーム画面ウィジェットで未完了タスクを最大4件表示
- **ホーム画面のウィジェットの項目をタップして完了**
- ウィジェットの「＋」から新しいタスクを作成

## 必要な環境

- Android 8.0以上（API 26+）の端末
- PCのAndroid Studio（最新の安定版を推奨）
- Android SDK 35、JDK 17、Gradle 8.9、Android Gradle Plugin 8.7.3
- 初回のGradle同期はインターネット接続が必要

> この提供物は **Android Studio用ソースプロジェクト** です。APK自体は入っていません。
> 作成環境にAndroid SDK / Gradleがないため、APK生成・実機動作テストは未実施です。

## PCでAPKを作る手順

1. ZIPを解凍します。
2. Android Studioを起動し、**Open** で解凍した `SuguTodo_Android` フォルダーを選択します。
3. Gradle同期が完了するまで進めます。Android SDK 35などの不足を求められたらインストールします。
4. プロジェクトにGradle Wrapper実行ファイルがないため、Android StudioにGradleの選択を促された場合は **Gradle 8.9のローカルインストール** を選択するか、Android StudioでWrapperを生成してください。`gradle/wrapper/gradle-wrapper.properties` は同梱しています。
5. Android Studioのメニューで **Build → Build Bundle(s) / APK(s) → Build APK(s)** を選択します（バージョンによってメニュー名が異なることがあります）。
6. 生成されたAPKは通常 `app/build/outputs/apk/debug/app-debug.apk` にあります。
7. APKをAndroidスマホに転送して開きます。必要に応じて「この提供元のアプリを許可」を設定してインストールします。

Android Studioで実機をUSB接続し、デバッグ実行（▶ Run）する方法でもインストールできます。

## ホーム画面ウィジェットの置き方

1. スマホのホーム画面の空きスペースを長押しします。
2. **ウィジェット** を開きます。
3. **すぐToDo・今日のタスク** を探し、ホーム画面に配置します。
4. タスクの行をタップすると、タスクを完了にできます。
5. 右上の「＋」を押すと、アプリのタスク追加画面が開きます。

機種・ホームアプリによりウィジェットの手順やサイズ表示は多少異なります。

## プロジェクト構成

```text
app/src/main/java/com/example/sugutodo/
  MainActivity.java         画面、追加・編集・削除・チェック操作
  Task.java                 タスクモデル
  TodoDb.java               SQLiteデータ保存
  TodoWidgetProvider.java   ホーム画面ウィジェット
  TaskActionReceiver.java   ウィジェットからの完了操作
app/src/main/res/layout/widget_todo.xml    ウィジェットの見た目
app/src/main/res/xml/todo_widget_info.xml  ウィジェット設定
```

## その他

- 通知リマインダー、クラウド同期、他端末同期は含みません。
- タスクはアプリ内に保存されます。アプリのデータ削除で消える可能性があります。
- インターネット通信・権限は不要です。
- ホーム画面のウィジェットが表示できるのは、Androidのネイティブアプリとしてビルド・インストールした場合です。

## GitHub ActionsでAPKを生成する（ビルド用PCなしの方法）

リポジトリにこのプロジェクトの**展開後の全ファイル**をアップロードすれば、付属の `.github/workflows/build-android.yml` がGitHubのサーバー上でAPKをビルドします。GitHubアカウントとネット接続が必要です。

1. GitHubで新しいリポジトリを作り、ZIPを**解凍した中身**をリポジトリ直下にアップロードします（ZIPファイルそのものを置くだけでは動きません）。
2. リポジトリの **Actions → Build Android APK → Run workflow** を実行します。`main` または `master` ブランチへのpushでも自動実行されます。
3. 成功した実行結果の **Artifacts → SuguTodo-debug-apk** をダウンロードして展開します。
4. `app-debug.apk` をAndroidで開き、インストールします。

初回のビルドには数分かかることがあります。実行成否はGitHub Actionsのログで確認してください。こちらの環境ではこのワークフローを実行・検証できていません。
